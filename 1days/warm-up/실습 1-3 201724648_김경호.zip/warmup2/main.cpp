#include <iostream>
using namespace std;

int main() {
    cout <<"강한친구 대한육군"<<endl;
    cout <<"강한친구 대한육군"<<endl;

    return 0;
}
